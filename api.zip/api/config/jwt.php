<?php
declare(strict_types=1);

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

require_once __DIR__ . '/../vendor/autoload.php';

function jwt_issue(array $claims): string {
  $now = time();
  $exp = $now + (int)($_ENV['JWT_EXP_SECONDS'] ?? 86400);
  $payload = array_merge([
    'iss' => $_ENV['JWT_ISS'] ?? 'burguersaurio.api',
    'aud' => $_ENV['JWT_AUD'] ?? 'burguersaurio.web',
    'iat' => $now,
    'nbf' => $now,
    'exp' => $exp,
  ], $claims);
  return JWT::encode($payload, $_ENV['JWT_SECRET'], 'HS256');
}

function jwt_parse_from_header(): ?object {
  $hdr = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
  if (!preg_match('/^Bearer\s+(.*)$/i', $hdr, $m)) return null;
  $token = $m[1];
  try {
    return JWT::decode($token, new Key($_ENV['JWT_SECRET'], 'HS256'));
  } catch (Throwable $e) {
    return null;
  }
}
