<?php
// Shim para compatibilidad con rutas antiguas: /api/login.php
require_once __DIR__ . '/auth/login.php';
