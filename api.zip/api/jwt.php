<?php
// Shim para compatibilidad con rutas antiguas: /api/jwt.php
require_once __DIR__ . '/config/jwt.php';
